package com.joydev.map.ui;

public interface IProfile {

    void onImageSelected(int resource);
}
